import React from 'react'
import Table from './components/Table'

function App() {
  return (
    <div className='w-full'>
      <Table/>
    </div>
  )
}

export default App